package myDao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import model.ContactsModel;

@Dao
public interface ContactsDao {

    @Query("SELECT * FROM contact_table WHERE cname LIKE :name")
    ContactsModel findByName(String name);

    @Insert
    void insertAll(ContactsModel... contact);


    @Delete
    void delete(ContactsModel contact);
}
