package model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity(tableName = "contact_table")
public class ContactsModel implements Serializable {

//    public ContactsModel(String cname, String cnum) {
//        this.cname = cname;
//        this.cnum = cnum;
//    }


    public ContactsModel(String cname, String cnum, String email, String image) {
        this.cname = cname;
        this.cnum = cnum;
        this.email = email;
        setEmail(email);
        this.image = image;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCnum() {
        return cnum;
    }

    public void setCnum(String cnum) {
        this.cnum = cnum;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
if(email!= null && email.length()>0)
        this.email = email;
else this.email = "Not Available";
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @PrimaryKey (autoGenerate = true)
    public int uid;

    @ColumnInfo(name = "Cname")
    public String cname;

    @ColumnInfo(name = "Cnum")
    public String cnum;


    @ColumnInfo(name = "Cemail")
    public String email;


    @ColumnInfo(name = "Cimage")
    public String image;


}
