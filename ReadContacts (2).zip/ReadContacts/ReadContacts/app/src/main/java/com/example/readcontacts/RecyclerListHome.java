package com.example.readcontacts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

import model.ContactsModel;
import mydatabase.ContactsDatabase;

public class RecyclerListHome extends AppCompatActivity {
    private ContactAdapter listAdapter;
//    private ArrayList<ContactModel> contactModelArrayList = new ArrayList<>();
    private ArrayList<ContactsModel> mycontactModelArrayList = new ArrayList<>();
    RecyclerView Recycler_View;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler__list__home);
        Recycler_View = findViewById(R.id.Recycler_View);
        context = this;
        readContacts();

    }

    public void readContacts() {
        String[] projection = { ContactsContract.CommonDataKinds.Email._ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS,
                ContactsContract.CommonDataKinds.Email.TYPE,
                ContactsContract.CommonDataKinds.Email.LABEL};
        Cursor phones = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null,
                null, ContactsContract.Contacts.DISPLAY_NAME + " ASC");
        if (phones.getCount() > 0) {
            while (phones.moveToNext()) {

                String phoneNumber = phones
                        .getString(phones
                                .getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                if (!TextUtils.isEmpty(phoneNumber)) {
                    String name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

                    String email = "";
                    if (phones
                            .getString(
                                    phones.getColumnIndex("mimetype"))
                            .equals(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)) {

                        // In this get all Emails like home, work etc and
                        // add them to email string
                        String homeEmail = "";
                        String workEmail = "";
                        switch (phones.getInt(phones
                                .getColumnIndex("data2"))) {
                            case ContactsContract.CommonDataKinds.Email.TYPE_OTHER:
                                homeEmail = phones.getString(phones
                                        .getColumnIndex("data1"));
                                email += "Home Email : "
                                        + homeEmail + "n";
                                Log.i("Recycler Home ","Email : "+homeEmail);
                                break;
                            case ContactsContract.CommonDataKinds.Email.TYPE_WORK:
                                workEmail = phones.getString(phones
                                        .getColumnIndex("data1"));
                                email += "Work Email : "
                                        + workEmail + "n";
                                Log.i("Recycler Home "," Work Email : "+workEmail);
                                break;

                        }
                    }


//                    String email = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Email.TYPE_HOME));
                    String image = phones.getString(phones.getColumnIndex(ContactsContract.Contacts.PHOTO_URI));

                    Log.i("MainActiuvity", name);
                    Log.i("MainActiuvity", phoneNumber);
//                    contactModelArrayList.add(new ContactModel(name, phoneNumber));
//                    mycontactModelArrayList.add(new ContactsModel(name, phoneNumber));
                    mycontactModelArrayList.add(new ContactsModel(name, phoneNumber, email, image));

//                    ContactsDatabase db = ContactsDatabase.getInstance(this);
//                    for(ContactsModel user : mycontactModelArrayList) {
//                        Log.d("User", user.cname);
//
//                        db.userDao().insertAll(user);
//
//                    }
                    setAdapter();
                }

            }

            insertTask(mycontactModelArrayList);
        } else {
            Toast.makeText(this, "No contact found", Toast.LENGTH_SHORT).show();
        }
        phones.close();
    }

    public void insertTask(final ArrayList<ContactsModel> note) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
//                noteDatabase.daoAccess().insertTask(note);
                ContactsDatabase db = ContactsDatabase.getInstance(context);
                for (ContactsModel user : note) {
                    Log.d("User", user.cname);

                    db.userDao().insertAll(user);

                }

                return null;
            }
        }.execute();
    }

    private void setAdapter() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        Recycler_View.setLayoutManager(layoutManager);
        listAdapter = new ContactAdapter(mycontactModelArrayList, this);
        Recycler_View.setAdapter(listAdapter);
    }

}
