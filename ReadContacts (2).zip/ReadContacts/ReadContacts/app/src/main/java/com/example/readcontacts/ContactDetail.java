package com.example.readcontacts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import model.ContactsModel;

public class ContactDetail extends AppCompatActivity {


    TextView tvNumber, tvName, tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        final ContactsModel contact = (ContactsModel) getIntent().getSerializableExtra("contact");


        tvNumber = findViewById(R.id.tvNumber);
        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);

        if (contact != null) {

            if (contact.getCname() != null)
                tvName.setText(contact.getCname());

            if (contact.getCnum() != null)
                tvNumber.setText(contact.getCnum());

            if (contact.getEmail() != null)
                tvEmail.setText(contact.getEmail());
        }
    }
}