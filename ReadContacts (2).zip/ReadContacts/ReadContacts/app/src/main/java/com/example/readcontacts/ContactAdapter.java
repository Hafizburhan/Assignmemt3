package com.example.readcontacts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import model.ContactsModel;

import static com.example.readcontacts.R.id.tvPhoneNo;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ContactHolder> {
    TextView tvName, tvPhoneNo;
    // List to store all the contact details
    private ArrayList<ContactsModel> contactsList;
    private Context mContext;

    // Counstructor for the Class
    public ContactAdapter(ArrayList<ContactsModel> contactsList, Context context) {
        this.contactsList = contactsList;
        this.mContext = context;
    }

    // This method creates views for the RecyclerView by inflating the layout
    // Into the viewHolders which helps to display the items in the RecyclerView
    @Override
    public ContactHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        // Inflate the layout view you have created for the list rows here
        View view = layoutInflater.inflate(R.layout.contact_list_view, parent, false);
        return new ContactHolder(view);
    }

    @Override
    public int getItemCount() {
        return contactsList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull ContactHolder holder, int position) {
        final ContactsModel contactModel = contactsList.get(position);
        holder.tvName.setText(contactModel.getCname());
        holder.tvName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, ContactDetail.class);
                intent.putExtra("contact", contactModel);
                mContext.startActivity(intent);
            }
        });
        holder.tvPhoneNo.setText(contactModel.getCnum());
        holder.tvEmail.setText(contactModel.getEmail());


    }

    public class ContactHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvPhoneNo;
        TextView tvEmail;

        public ContactHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvPhoneNo = itemView.findViewById(R.id.tvPhoneNo);
            tvEmail = itemView.findViewById(R.id.tvEmail);
        }

        public TextView getTvName() {
            return tvName;
        }

        public TextView getTvPhoneNo() {
            return tvPhoneNo;
        }

        public void setTvName(TextView tvName) {
            this.tvName = tvName;
        }

        public void setTvPhoneNo(TextView tvPhoneNo) {
            this.tvPhoneNo = tvPhoneNo;
        }
    }
}
