package com.example.readcontacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import model.SharedPreferenceHelper;

public class MyLoginActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    CheckBox cbRememberMe;

    Button btnLogin;

    Context context ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_login);

        context = this;

        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);

        cbRememberMe = findViewById(R.id.checkBox);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isUserNameValid(etUsername.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "User Name is not valid", Toast.LENGTH_SHORT).show();

                    return;
                }
                if (isPasswordValid(etPassword.getText().toString())) {
                    SharedPreferenceHelper.setString(context,SharedPreferenceHelper.USER_NAME,etUsername.getText().toString());
                    SharedPreferenceHelper.setString(context,SharedPreferenceHelper.USER_PASS,etPassword.getText().toString());

                    if (cbRememberMe.isChecked()) {
                       SharedPreferenceHelper.setSPBoolean(context,SharedPreferenceHelper.IS_REMEMBER,true);
                    }else {
                        SharedPreferenceHelper.setSPBoolean(context,SharedPreferenceHelper.IS_REMEMBER,false);

                    }

                    Intent intent = new Intent(context, RecyclerListHome.class);
                    startActivity(intent);
                    finish();

                }else {


                    Toast.makeText(getApplicationContext(), "Password is not valid", Toast.LENGTH_SHORT).show();
return;
                }
            }
        });


    }

    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username != null && username.trim().length() > 0) {
            return true;
        } else
            return false;
//        if (username.contains("@")) {
//            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
//        } else {
//            return !username.trim().isEmpty();
//        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }
}