package mydatabase;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import myDao.ContactsDao;
import model.ContactsModel;


@Database(entities = {ContactsModel.class}, version = 2)
public abstract class ContactsDatabase extends RoomDatabase {


    public static final String CONTACT_DB_NAME = "contactsDb";
    private static ContactsDatabase instance;

    public static synchronized ContactsDatabase getInstance(Context context) {
        if (instance == null) {

            instance = Room.databaseBuilder(context.getApplicationContext(), ContactsDatabase.class, CONTACT_DB_NAME).fallbackToDestructiveMigration().build();
        }
        return instance;
    }




    public abstract ContactsDao userDao();
}

